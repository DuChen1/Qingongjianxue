//获取XMLHttpRequest对象
function getXMLHttpRequest(){
    var xmlHttp;
    //IE7+,FireFox,Chrome,Opera,Safari
    if(window.XMLHttpRequest){
        xmlHttp = new XMLHttpRequest();
    }else{//ie6,ie5
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    return xmlHttp;
}